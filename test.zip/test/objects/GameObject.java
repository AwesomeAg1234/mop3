// 
// Decompiled by Procyon v0.5.36
// 

package objects;

public class GameObject implements Comparable<GameObject>
{
    private int type;
    private int x;
    private int y;
    private int radius;
    private int id;
    private int velocityX;
    private int velocityY;
    
    public GameObject(final int id, final int x, final int y, final int radius, final int type) {
        this.type = type;
        this.id = id;
        this.x = Math.max(x, 0);
        this.y = Math.max(y, 0);
        this.radius = radius;
        this.setVelocityX(0);
        this.setVelocityY(0);
    }
    
    @Override
    public int compareTo(final GameObject o) {
        if (o.type != 2) {
            return 0;
        }
        int score = 0;
        score = ((Player)o).getScore() - ((Player)this).getScore();
        if (score == 0) {
            score = ((Player)o).getId() - ((Player)this).getId();
        }
        return score;
    }
    
    public int getType() {
        return this.type;
    }
    
    public void setType(final int type) {
        this.type = type;
    }
    
    public int getX() {
        return this.x;
    }
    
    public void setX(final int x) {
        this.x = Math.max(x, 0);
    }
    
    public int getY() {
        return this.y;
    }
    
    public void setY(final int y) {
        this.y = Math.max(y, 0);
    }
    
    public int getRadius() {
        return this.radius;
    }
    
    public void setRadius(final int radius) {
        this.radius = radius;
    }
    
    public int getId() {
        return this.id;
    }
    
    public void setId(final int id) {
        this.id = id;
    }
    
    public void update() {
        this.setX(this.getX() + this.getVelocityX());
        this.setY(this.getY() + this.getVelocityY());
        if (this.x >= 6840 - this.radius) {
            this.x = 6840 - this.radius - 1;
        }
        if (this.y >= 6840 - this.radius) {
            this.y = 6840 - this.radius - 1;
        }
    }
    
    public int getVelocityX() {
        return this.velocityX;
    }
    
    public void setVelocityX(final int velocityX) {
        this.velocityX = velocityX;
    }
    
    public int getVelocityY() {
        return this.velocityY;
    }
    
    public void setVelocityY(final int velocityY) {
        this.velocityY = velocityY;
    }
}
