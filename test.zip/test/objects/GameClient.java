
package objects;

import java.util.Iterator;
import tools.NetworkingTools;
import server.MsgWriter;
import java.util.concurrent.ThreadLocalRandom;
import server.MsgReader;
import world.Room;
import org.java_websocket.WebSocket;

public class GameClient
{
    private WebSocket socket;
    private Player player;
    private Room room;
    
    public Player getPlayer() {
        return this.player;
    }
    
    public void setPlayer(final Player player) {
        this.player = player;
    }
    
    public Room getRoom() {
        return this.room;
    }
    
    public void setRoom(final Room room) {
        this.room = room;
    }
    
    public void setSocket(final WebSocket socket) {
        this.socket = socket;
    }
    
    public GameClient(final WebSocket socket, final Room room) {
        this.player = null;
        this.socket = socket;
        this.room = room;
    }
    
    public void onclose() {
        try {
            this.room.removePlayer(this.player);
        }
        catch (Exception ex) {}
    }
    
    public void onopen() {
    }
    
    public void onmessage(final MsgReader reader) {
        int type = 0;
        try {
            type = reader.readUInt8();
        }
        catch (Exception e) {
            return;
        }
        switch (type) {
            case 2: {
                try {
                    final String playerName = reader.readString();
                    final boolean isSpectator = reader.readUInt8() == 2;
                    if (isSpectator) {
                        final Player player = new Player(this.room.object_id, ThreadLocalRandom.current().nextInt(0, 6841), ThreadLocalRandom.current().nextInt(0, 6841), playerName.trim(), this);
                        final Room room = this.room;
                        ++room.object_id;
                        this.player = player;
                        this.room.addSpectator(this.player);
                    }
                    else {
                        this.player.setPlayerName(playerName.trim());
                        this.player.setSpectator(isSpectator);
                        this.player.setX(ThreadLocalRandom.current().nextInt(0, 6841));
                        this.player.setY(ThreadLocalRandom.current().nextInt(0, 6841));
                        this.player.setZoom(4000);
                        this.room.initPlayer(this.player);
                    }
                }
                catch (Exception e) {
                    this.socket.close();
                }
                break;
            }
            case 5: {
                try {
                    this.player.setMouseX(reader.readInt16());
                    this.player.setMouseY(reader.readInt16());
                }
                catch (Exception e) {
                    this.socket.close();
                }
                break;
            }
            case 21: {
                try {
                    this.player.setMouseDown(reader.readUInt8() != 0);
                }
                catch (Exception e) {
                    this.socket.close();
                }
                break;
            }
            case 255: {
                final MsgWriter writerForPing = new MsgWriter();
                writerForPing.writeUInt8(255);
                NetworkingTools.sendMessage(this.getSocket(), writerForPing);
                break;
            }
            case 20: {
                try {
                    this.player.setHoldingW(reader.readUInt8() == 1);
                }
                catch (Exception ex) {}
            }
            case 19: {
                try {
                    if (!this.player.isSpectator()) {
                        final String message = reader.readString().trim();
                        if (!message.equals("")) {
                            if (message.startsWith("xp:")) {
                                this.player.setScore(Integer.parseInt(message.split(":")[1]));
                            }
                            else if (message.startsWith("a:")) {
                                this.player.setAnimal(Integer.parseInt(message.split(":")[1]));
                                this.player.setWater(100);
                                this.player.setCreatedAt(System.currentTimeMillis());
                                this.player.setFlag(8);
                                NetworkingTools.sendMessage(this.socket, NetworkingTools.upgrade(this.player));
                            }
                            else if (message.startsWith("n:")) {
                                this.player.setPlayerName(message.split(":")[1]);
                            }
                            /*else if (message.startsWith("gm:")) {
                                int forloopwater = 0;
                                //var result = message.split("1")[1];

                                if (Integer.parseInt(message.split(":")[1]) == 1) {
                                    while(forloopwater < 5) {
                                    this.player.setWater(99999);
                                }
                                }
                                else if(Integer.parseInt(message.split(":")[1]) == 0) {
                                    forloopwater = 40;
                                    this.player.setWater(100);
                                }
                            }*/
                            else if (message.startsWith("kill:me")) {
                                this.socket.close();
                            }
                            else {
                                final MsgWriter writer = new MsgWriter();
                                writer.writeUInt8(19);
                                writer.writeUInt32(this.player.isInHole() ? this.player.getHole() : this.player.getId());
                                writer.writeString(message);
                                for (final GameObject object : this.room.objects) {
                                    if (object.getType() == 2) {
                                        NetworkingTools.sendMessage(((Player)object).getClient().getSocket(), writer);
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception e2) {
                    this.socket.close();
                }
                break;
            }
        }
    }
    
    public WebSocket getSocket() {
        return this.socket;
    }
}