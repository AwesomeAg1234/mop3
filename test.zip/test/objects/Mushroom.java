// 
// Decompiled by Procyon v0.5.36
// 

package objects;

import java.util.concurrent.ThreadLocalRandom;
import java.util.Iterator;
import world.Room;

public class Mushroom extends ProtoEdible
{
    public Mushroom(final int id, final int x, final int y, final int radius, final int type, final Room room) {
        super(id, x, y, radius, type, room, null);
    }
    
    @Override
    public void kill(final Player killer) {
        if (killer.getAnimal() >= 3 && killer.getAnimal() != 9) {
            if (killer.getAnimal() == 3) {
                killer.setScore(killer.getScore() + 8);
            }
            else {
                killer.setScore(killer.getScore() + 25);
            }
            this.room.objects.remove(this);
            for (final GameObject player : this.room.objects) {
                if (player.getType() == 2) {
                    ((Player)player).removalMap.put(this, killer);
                    ((Player)player).toRemove.add(this);
                }
            }
            this.respawn();
        }
    }
    
    @Override
    public void respawn() {
        final ProtoEdible food = new Mushroom(this.room.object_id, ThreadLocalRandom.current().nextInt(0, 6841), ThreadLocalRandom.current().nextInt(0, 6841), this.getRadius(), this.getType(), this.room);
        this.room.objects.add(food);
        final Room room = this.room;
        ++room.object_id;
        for (final GameObject player : this.room.objects) {
            if (player.getType() == 2) {
                ((Player)player).toAdd.add(food);
            }
        }
    }
}
