// 
// Decompiled by Procyon v0.5.36
// 

package objects;

import java.util.concurrent.ThreadLocalRandom;
import java.util.Iterator;
import world.Room;

public class ProtoEdible extends GameObject
{
    protected Room room;
    protected ProtoGenerator origin;
    
    public ProtoEdible(final int id, final int x, final int y, final int radius, final int type, final Room room, final ProtoGenerator origin) {
        super(id, x, y, radius, type);
        this.room = room;
        this.origin = origin;
    }
    
    @Override
    public void update() {
        for (final GameObject object : this.room.objects) {
            if (object.getType() == 2 && !((Player)object).isSpectator() && ((Player)object).getFlag() != 16 && this.room.collisionTest(this, object)) {
                this.kill((Player)object);
            }
            else {
                if (object.getType() == 2 || object.getType() == 10 || object.getId() == this.getId() || object.getType() == 6 || object.getType() == 11) {
                    continue;
                }
                try {
                    ((ProtoEdible)object).getType();
                }
                catch (Exception e) {
                    this.room.collision(object, this);
                }
            }
        }
        if (this.getX() >= 6840 - this.getRadius()) {
            this.setX(6840 - this.getRadius() - 1);
        }
        if (this.getY() >= 6840 - this.getRadius()) {
            this.setY(6840 - this.getRadius() - 1);
        }
    }
    
    public void kill(final Player killer) {
        if (killer.getAnimal() != 5) {
            killer.setScore(killer.getScore() + 1);
            this.room.objects.remove(this);
            for (final GameObject player : this.room.objects) {
                if (player.getType() == 2) {
                    ((Player)player).removalMap.put(this, killer);
                    ((Player)player).toRemove.add(this);
                }
            }
            this.respawn();
        }
    }
    
    public void respawn() {
        if (this.origin != null) {
            final ProtoGenerator origin = this.origin;
            --origin.amount;
        }
        else {
            final ProtoEdible food = new ProtoEdible(this.room.object_id, ThreadLocalRandom.current().nextInt(0, 6841), ThreadLocalRandom.current().nextInt(0, 6841), this.getRadius(), this.getType(), this.room, this.origin);
            this.room.objects.add(food);
            final Room room = this.room;
            ++room.object_id;
            for (final GameObject player : this.room.objects) {
                if (player.getType() == 2) {
                    ((Player)player).toAdd.add(food);
                }
            }
        }
    }
}
