// 
// Decompiled by Procyon v0.5.36
// 

package objects;

import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom;
import world.Room;

public class FoodSpot extends ProtoGenerator
{
    public int cooldown;
    public Room room;
    
    public FoodSpot(final int id, final int x, final int y, final int radius, final int type, final Room room) {
        super(id, x, y, radius, type);
        this.cooldown = 0;
        this.room = room;
    }
    
    @Override
    public void update() {
        ++this.cooldown;
        if (this.amount < 35 && this.cooldown >= 50) {
            this.cooldown = 0;
            ++this.amount;
            final int x = ThreadLocalRandom.current().nextInt(this.getX() - this.getRadius() / 2, this.getX() + this.getRadius() / 2);
            final int y = ThreadLocalRandom.current().nextInt(this.getY() - this.getRadius() / 2, this.getY() + this.getRadius() / 2);
            final int radius = (ThreadLocalRandom.current().nextInt(0, 100) > 25) ? 42 : 60;
            final GameObject object = new ProtoEdible(this.room.object_id, x, y, radius, 6, this.room, this);
            final Room room = this.room;
            ++room.object_id;
            this.room.objects.add(object);
            for (final GameObject player : this.room.objects) {
                if (player.getType() == 2) {
                    ((Player)player).toAdd.add(object);
                }
            }
        }
    }
}
