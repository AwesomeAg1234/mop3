// 
// Decompiled by Procyon v0.5.36
// 

package objects;

public class ProtoGenerator extends GameObject
{
    public int amount;
    
    public ProtoGenerator(final int id, final int x, final int y, final int radius, final int type) {
        super(id, x, y, radius, type);
        this.amount = 0;
    }
}
