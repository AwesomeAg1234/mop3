// 
// Decompiled by Procyon v0.5.36
// 

package objects;

import java.util.Iterator;
import world.Room;

public class Lilypad extends ProtoEdible
{
    public Lilypad(final int id, final int x, final int y, final int radius, final int type, final Room room) {
        super(id, x, y, radius, type, room, null);
    }
    
    @Override
    public void kill(final Player killer) {
        if (killer.getAnimal() >= 5 && killer.getAnimal() != 9) {
            killer.setScore(killer.getScore() + 75);
            this.room.objects.remove(this);
            for (final GameObject player : this.room.objects) {
                if (player.getType() == 2) {
                    ((Player)player).removalMap.put(this, killer);
                    ((Player)player).toRemove.add(this);
                }
            }
            this.respawn();
        }
    }
    
    @Override
    public void respawn() {
    }
}
