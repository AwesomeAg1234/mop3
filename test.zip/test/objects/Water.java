// 
// Decompiled by Procyon v0.5.36
// 

package objects;

import java.util.Iterator;
import world.Room;

public class Water extends ProtoEdible
{
    public Water(final int id, final int x, final int y, final int radius, final int type, final Room room, final ProtoGenerator gen) {
        super(id, x, y, radius, type, room, gen);
    }
    
    @Override
    public void kill(final Player killer) {
        if (killer.getWater() < 100) {
            killer.setWater(killer.getWater() + 3);
            this.room.objects.remove(this);
            for (final GameObject player : this.room.objects) {
                if (player.getType() == 2) {
                    ((Player)player).removalMap.put(this, killer);
                    ((Player)player).toRemove.add(this);
                }
            }
            if (this.origin != null) {
                final ProtoGenerator origin = this.origin;
                --origin.amount;
            }
        }
    }
}
