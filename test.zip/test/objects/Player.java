// 
// Decompiled by Procyon v0.5.36
// 

package objects;

import world.Room;
import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom;
import tools.NetworkingTools;
import tools.Tools;
import java.util.HashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.Map;
import java.util.List;

public class Player extends GameObject
{
    private int score;
    private int cooldown;
    private int rank;
    private int zoom;
    private int angle;
    private int mouseX;
    private int mouseY;
    private int animal;
    private int water;
    private int waterTimer;
    private GameClient client;
    private boolean spectator;
    private boolean mouseDown;
    private String playerName;
    private int airLevel;
    private int airTimer;
    private int flag;
    private boolean holdingW;
    private int lastAni;
    private boolean inWater;
    private int first;
    private int water_pending_removal;
    private boolean inHole;
    private int hole;
    private long createdAt;
    private long lastUpdate;
    public List<GameObject> toAdd;
    public List<GameObject> toRemove;
    public Map<GameObject, GameObject> removalMap;
    public boolean spawned;
    
    public int getWaterTimer() {
        return this.waterTimer;
    }
    
    public void setWaterTimer(final int waterTimer) {
        this.waterTimer = waterTimer;
    }
    
    public boolean isHoldingW() {
        return this.holdingW;
    }
    
    public void setHoldingW(final boolean holdingW) {
        this.holdingW = holdingW;
    }
    
    public int getFirst() {
        return this.first;
    }
    
    public void setFirst(final int first) {
        this.first = first;
    }
    
    public int getWater_pending_removal() {
        return this.water_pending_removal;
    }
    
    public void setWater_pending_removal(final int water_pending_removal) {
        this.water_pending_removal = water_pending_removal;
    }
    
    public long getLastUpdate() {
        return this.lastUpdate;
    }
    
    public void setLastUpdate(final long lastUpdate) {
        this.lastUpdate = lastUpdate;
    }
    
    public List<GameObject> getToAdd() {
        return this.toAdd;
    }
    
    public void setToAdd(final List<GameObject> toAdd) {
        this.toAdd = toAdd;
    }
    
    public List<GameObject> getToRemove() {
        return this.toRemove;
    }
    
    public void setToRemove(final List<GameObject> toRemove) {
        this.toRemove = toRemove;
    }
    
    public Map<GameObject, GameObject> getRemovalMap() {
        return this.removalMap;
    }
    
    public void setRemovalMap(final Map<GameObject, GameObject> removalMap) {
        this.removalMap = removalMap;
    }
    
    public boolean isSpawned() {
        return this.spawned;
    }
    
    public void setSpawned(final boolean spawned) {
        this.spawned = spawned;
    }
    
    public void setLastAni(final int lastAni) {
        this.lastAni = lastAni;
    }
    
    public Player(final int id, final int x, final int y, final String playerName, final GameClient client) {
        super(id, x, y, 42, 2);
        this.score = 0;
        this.cooldown = 0;
        this.rank = 0;
        this.zoom = 4000;
        this.angle = 0;
        this.mouseX = 0;
        this.mouseY = 0;
        this.animal = 1;
        this.water = 100;
        this.waterTimer = 25;
        this.spectator = true;
        this.mouseDown = false;
        this.airLevel = 100;
        this.airTimer = 25;
        this.flag = 8;
        this.holdingW = false;
        this.lastAni = 0;
        this.inWater = false;
        this.first = 1;
        this.water_pending_removal = 0;
        this.inHole = false;
        this.hole = 0;
        this.createdAt = System.currentTimeMillis();
        this.lastUpdate = System.currentTimeMillis();
        this.toAdd = new CopyOnWriteArrayList<GameObject>();
        this.toRemove = new CopyOnWriteArrayList<GameObject>();
        this.removalMap = new HashMap<GameObject, GameObject>();
        this.spawned = true;
        this.client = client;
        this.playerName = playerName;
    }
    
    public void reset() {
        this.zoom = 4000;
        this.angle = 0;
        this.flag = 8;
        this.rank = 0;
        this.first = 1;
        this.spawned = true;
        this.cooldown = 0;
        this.setCreatedAt(System.currentTimeMillis());
        this.mouseDown = false;
        this.mouseX = 0;
        this.inHole = false;
        this.hole = 0;
        this.mouseY = 0;
        this.water = 100;
        this.animal = 1;
    }
    
    public int getCooldown() {
        return this.cooldown;
    }
    
    public void setCooldown(final int cooldown) {
        this.cooldown = cooldown;
    }
    
    public int getWater() {
        return this.water;
    }
    
    public void setWater(final int water) {
        this.water = Math.min(water, 100);
    }
    
    public int getAnimal() {
        return this.animal;
    }
    
    public void setAnimal(final int animal) {
        this.animal = animal;
    }
    
    public int getMouseX() {
        return this.mouseX;
    }
    
    public void setMouseX(final int mouseX) {
        this.mouseX = mouseX * 4;
    }
    
    public int getMouseY() {
        return this.mouseY;
    }
    
    public void setMouseY(final int mouseY) {
        this.mouseY = mouseY * 4;
    }
    
    public int getZoom() {
        return this.zoom;
    }
    
    public void setZoom(final int zoom) {
        this.zoom = zoom;
    }
    
    public int getAngle() {
        return this.angle;
    }
    
    public void setAngle(final int angle) {
        this.angle = angle;
    }
    
    public boolean isMouseDown() {
        return this.mouseDown;
    }
    
    public void setMouseDown(final boolean mouseDown) {
        this.mouseDown = mouseDown;
    }
    
    public String getPlayerName() {
        return this.playerName;
    }
    
    public void setPlayerName(final String playerName) {
        this.playerName = playerName;
    }
    
    public void setClient(final GameClient client) {
        this.client = client;
    }
    
    public int getScore() {
        return this.score;
    }
    
    public boolean isSpectator() {
        return this.spectator;
    }
    
    public void setSpectator(final boolean spectator) {
        this.spectator = spectator;
    }
    
    public void setScore(final int score) {
        this.score = score;
    }
    
    @Override
    public void update() {
        final long time = (System.currentTimeMillis() - this.lastUpdate) / 40L;
        if (this.spectator) {
            if (this.getX() >= 6840) {
                this.setVelocityX((int)(-5L * time));
            }
            if (this.getY() >= 6840) {
                this.setVelocityY((int)(-5L * time));
            }
            if (this.getX() < this.getRadius()) {
                this.setX(this.getRadius() - 1);
                this.setVelocityX((int)(20L * time));
            }
            if (this.getY() < this.getRadius()) {
                this.setY(this.getRadius() - 1);
                this.setVelocityY((int)(20L * time));
            }
            this.setCreatedAt(System.currentTimeMillis());
        }
        else {
            int speed = 20;
            if (this.getX() <= 1800) {
                this.inWater = true;
            }
            else if (this.getX() >= 5040) {
                this.inWater = true;
            }
            else {
                this.inWater = false;
            }
            final long amount = this.spawned ? 5000 : 3000;
            if (this.flag == 8 && System.currentTimeMillis() - this.getCreatedAt() >= amount) {
                this.flag = 0;
                this.spawned = false;
            }
            if (this.flag != 8 && this.holdingW && this.inWater) {
                this.flag = 16;
            }
            if (this.flag == 16 && (!this.inWater || !this.holdingW)) {
                this.flag = 0;
                this.airLevel = 100;
            }
            if (this.animal < 14 && this.score >= Tools.getNextAnimalGrowth(this)) {
                this.lastAni = Tools.getNextAnimalGrowth(this);
                this.animal = Tools.getNextLogicalAnimal(this);
                this.water = 100;
                this.createdAt = System.currentTimeMillis();
                this.flag = 8;
                try {
                    NetworkingTools.sendMessage(this.getClient().getSocket(), NetworkingTools.upgrade(this));
                }
                catch (Exception ex) {}
            }
            this.zoom = 4000;
            double percentage = (this.score - this.lastAni) / (double)(Tools.getNextAnimalGrowth(this) - this.lastAni);
            percentage *= 100.0;
            if (this.animal >= 14) {
                percentage = 100.0;
            }
            final int radius = (int)(Tools.getMinSize(this) + Math.round(percentage) / 3L);
            this.setRadius(radius);
            this.zoom -= radius * 10;
            if (this.animal >= 14) {
                this.zoom = 4000;
                this.setRadius(150);
                this.zoom -= this.getRadius() * 10;
                speed = 15;
            }
            if (this.airTimer < 0) {
                this.airTimer = 25;
                --this.airLevel;
            }
            if (this.airLevel <= 0) {
                this.airLevel = 100;
                this.flag = 0;
            }
            if (this.waterTimer < 0) {
                this.waterTimer = 25;
                if (this.inWater) {
                    this.water = Math.min(this.water + 2, 100);
                }
                else {
                    this.water_pending_removal += 2;
                }
            }
            if (this.animal == 10) {
                speed = 15;
            }
            if (this.mouseDown && this.cooldown < 0 && this.water >= 30) {
                speed = 140;
                if (this.animal == 9) {
                    speed += 50;
                }
                this.water_pending_removal += 2;
                this.cooldown = 25;
            }
            boolean inMud = false;
            if (this.water < 25) {
                this.setFlag(192);
            }
            else if (this.flag == 192) {
                this.setFlag(0);
            }
            this.cooldown -= (int)(1L * time);
            this.waterTimer -= (int)(1L * time);
            this.airTimer -= (int)(10L * time);
            if (this.water <= 0) {
                this.getClient().getRoom().killPlayer(this, 4, this);
            }
            if (this.flag != 16) {
                for (final GameObject object : this.getClient().getRoom().objects) {
                    if (object.getType() == 11) {
                        if (!this.client.getRoom().collisionTest(this, object)) {
                            continue;
                        }
                        inMud = true;
                        if (Tools.fastInMud(this)) {
                            continue;
                        }
                        speed /= 3;
                    }
                    else {
                        if (object.getType() == 11 || object.getId() == this.getId()) {
                            continue;
                        }
                        if (this.animal != 14||this.animal != 37) {
                            if (object.getType() == 8) {
                                if (this.animal < 3 || this.animal == 9) {
                                    this.getClient().getRoom().collision(this, object);
                                }
                            }
                            else if (object.getType() == 3 && this.animal != 10) {
                                this.getClient().getRoom().collision(object, this);
                            }
                            else if (object.getType() != 10 && object.getType() != 6 && object.getType() != 7) {
                                if (this.animal < 4 && object.getType() == 5) {
                                    this.getClient().getRoom().collision(object, this);
                                }
                                if (this.animal == 11) {
                                    if (object.getType() == 5) {
                                        this.getClient().getRoom().collision(object, this);
                                    }
                                }
                                else if (object.getType() == 4 && this.animal != 13) {
                                    this.getClient().getRoom().collision(object, this);
                                }
                                else if (object.getType() == 17 && this.animal >= 5) {
                                    this.getClient().getRoom().collision(object, this);
                                }
                            }
                        }
                        if (object.getType() == 2 && ((Player)object).getAnimal() == this.animal) {
                            this.getClient().getRoom().collision(object, this);
                        }
                        else if (object.getType() == 12 && (this.animal != 14 || this.animal != 37)) {
                    
                            this.getClient().getRoom().collision(object, this);
                            
                        }
                        else {
                            if (object.getType() != 15 || (this.animal >= 5 && this.animal != 9)) {
                                continue;
                            }
                            this.getClient().getRoom().collision(this, object);
                        }
                    }
                }
            }
            if (this.flag != 16 && this.inWater && !Tools.fastInMud(this)) {
                speed /= 3;
            }
            if (this.flag == 16) {
                speed /= 3;
            }
            this.angle = Tools.getAngle(this, 0);
            this.setVelocityX((int)(Math.cos(Math.toRadians(this.angle)) * speed));
            this.setVelocityY((int)(Math.sin(Math.toRadians(this.angle)) * speed));
            if (!inMud && this.flag != 8) {
                this.water -= this.water_pending_removal;
            }
            this.water_pending_removal = 0;
        }
        this.setX(this.getX() + this.getVelocityX());
        this.setY(this.getY() + this.getVelocityY());
        if (!this.spectator) {
            if (this.getX() < this.getRadius()) {
                this.setX(this.getRadius() - 1);
            }
            if (this.getY() < this.getRadius()) {
                this.setY(this.getRadius() - 1);
            }
            if (this.getX() >= 6840 - this.getRadius()) {
                this.setX(6840 - this.getRadius() - 1);
            }
            if (this.getY() >= 6840 - this.getRadius()) {
                this.setY(6840 - this.getRadius() - 1);
            }
            for (final GameObject object2 : this.client.getRoom().objects) {
                if (object2.getType() == 2 && object2.getId() != this.getId() && !((Player)object2).isSpectator() && this.animal > ((Player)object2).animal && this.client.getRoom().collisionTest(this, object2)) {
                    double percentage2 = ((Player)object2).score / (double)Tools.getNextAnimalGrowth((Player)object2);
                    percentage2 *= 100.0;
                    if (((Player)object2).animal >= 14) {
                        percentage2 = 100.0;
                    }
                    if (percentage2 <= 25.0 || ((Player)object2).animal == 14) {
                        this.client.getRoom().killPlayer((Player)object2, 1, this);
                        for (int i = 0; i < 3; ++i) {
                            final int x = ThreadLocalRandom.current().nextInt(((Player)object2).getX() - ((Player)object2).getRadius(), ((Player)object2).getX() + ((Player)object2).getRadius());
                            final int y = ThreadLocalRandom.current().nextInt(((Player)object2).getY() - ((Player)object2).getRadius(), ((Player)object2).getY() + ((Player)object2).getRadius());
                            final int radius2 = 42;
                            final GameObject water = new Water(this.client.getRoom().object_id, x, y, radius2, 7, this.client.getRoom(), null);
                            final Room room = this.client.getRoom();
                            ++room.object_id;
                            this.client.getRoom().objects.add(water);
                            for (final GameObject player : this.client.getRoom().objects) {
                                if (player.getType() == 2) {
                                    ((Player)player).toAdd.add(water);
                                }
                            }
                        }
                    }
                    else {
                        ((Player)object2).setX((int)(Math.cos(Math.toRadians(this.angle)) * 270.0));
                        ((Player)object2).setY((int)(Math.sin(Math.toRadians(this.angle)) * 270.0));
                        this.score += ((Math.round((float)(((Player)object2).score / 2)) > 0) ? Math.round((float)(((Player)object2).score / 2)) : 1);
                        ((Player)object2).score = Math.round((float)(((Player)object2).score / 2));
                    }
                }
            }
        }
        if (this.inHole && !this.getClient().getRoom().collisionTest(this, (GameObject)this.getClient().getRoom().objects.get(this.hole))) {
            for (final GameObject player2 : this.getClient().getRoom().objects) {
                if (player2.getType() == 2) {
                    ((Player)player2).toAdd.add(this);
                }
            }
            this.inHole = false;
            this.hole = 0;
        }
        this.lastUpdate = System.currentTimeMillis();
        NetworkingTools.sendMessage(this.getClient().getSocket(), NetworkingTools.sendUpdatePacket(this.getClient().getRoom(), this, this.first));
        this.first = 0;
    }
    
    public GameClient getClient() {
        return this.client;
    }
    
    public int getRank() {
        return this.rank;
    }
    
    public void setRank(final int rank) {
        this.rank = rank;
    }
    
    public int getFlag() {
        return this.flag;
    }
    
    public void setFlag(final int flag) {
        this.flag = flag;
    }
    
    public long getCreatedAt() {
        return this.createdAt;
    }
    
    public void setCreatedAt(final long createdAt) {
        this.createdAt = createdAt;
    }
    
    public double getLastAni() {
        return this.lastAni;
    }
    
    public boolean isInHole() {
        return this.inHole;
    }
    
    public void setInHole(final boolean inHole) {
        this.inHole = inHole;
    }
    
    public int getHole() {
        return this.hole;
    }
    
    public void setHole(final int hole) {
        this.hole = hole;
    }
    
    public int getAirLevel() {
        return this.airLevel;
    }
}
