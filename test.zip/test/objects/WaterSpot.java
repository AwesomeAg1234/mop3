// 
// Decompiled by Procyon v0.5.36
// 

package objects;

import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom;
import world.Room;

public class WaterSpot extends ProtoGenerator
{
    public int cooldown;
    public Room room;
    
    public WaterSpot(final int id, final int x, final int y, final int radius, final int type, final Room room) {
        super(id, x, y, radius, type);
        this.cooldown = 0;
        this.room = room;
    }
    
    @Override
    public void update() {
        ++this.cooldown;
        if (this.amount < 25 && this.cooldown >= 25) {
            this.cooldown = 0;
            ++this.amount;
            final int x = ThreadLocalRandom.current().nextInt(this.getX() - this.getRadius() / 2, this.getX() + this.getRadius() / 2);
            final int y = ThreadLocalRandom.current().nextInt(this.getY() - this.getRadius() / 2, this.getY() + this.getRadius() / 2);
            final Water object = new Water(this.room.object_id, x, y, 42, 7, this.room, this);
            final Room room = this.room;
            ++room.object_id;
            this.room.objects.add(object);
            for (final GameObject player : this.room.objects) {
                if (player.getType() == 2) {
                    ((Player)player).toAdd.add(object);
                }
            }
        }
    }
}
