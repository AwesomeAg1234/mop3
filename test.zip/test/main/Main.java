// 
// Decompiled by Procyon v0.5.36
// 

package main;

import tools.NetworkingTools;
import objects.GameClient;
import java.net.UnknownHostException;
import org.java_websocket.drafts.Draft;
import server.Server;
import org.java_websocket.drafts.Draft_6455;
import world.Room;
import java.util.concurrent.ConcurrentHashMap;

public class Main
{
    public ConcurrentHashMap<Integer, Room> rooms;
    
    public Main() {
        this.rooms = new ConcurrentHashMap<Integer, Room>();
        for (int i = 1; i < 2; ++i) {
            final Room room = new Room(i, this);
            this.rooms.put(i, room);
            new Thread(room).start();
        }
        Server test = null;
        try {
            test = new Server(7020, (Draft)new Draft_6455(), this);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        test.setConnectionLostTimeout(0);
        test.start();
    }
    
    public static void main(final String[] args) {
        new Main();
    }
    
    public void handleNewClient(final GameClient client, final Room room) {
        client.getSocket().send(NetworkingTools.initClient(room).getData());
    }
}
