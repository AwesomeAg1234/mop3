// 
// Decompiled by Procyon v0.5.36
// 

package world;

import java.util.Map;
import server.MsgWriter;
import tools.NetworkingTools;
import java.util.List;
import java.util.Collections;
import objects.Player;
import java.util.ArrayList;
import java.util.Iterator;
import objects.Mushroom;
import objects.RedMushroom;
import objects.ProtoGenerator;
import objects.ProtoEdible;
import objects.WaterSpot;
import objects.FoodSpot;
import objects.Lilypad;
import java.util.concurrent.ThreadLocalRandom;
import java.util.Random;
import objects.GameObject;
import java.util.concurrent.CopyOnWriteArrayList;
import main.Main;
import tools.GameList;

public class Room extends Thread
{
    public GameList objects;
    public int id;
    public short playerCount;
    public int object_id;
    private Main main;
    public CopyOnWriteArrayList<GameObject> leaderboard;
    
    public Room(final int id, final Main main) {
        this.objects = new GameList();
        this.object_id = 2;
        this.leaderboard = new CopyOnWriteArrayList<GameObject>();
        this.id = id;
        this.playerCount = 0;
        this.main = main;
    }
    
    private void generate() {
        final Random random = new Random();
        for (int i = 0; i < 50; ++i) {
            final int size = random.nextBoolean() ? 150 : 200;
            this.objects.add(new GameObject(this.object_id, ThreadLocalRandom.current().nextInt((0 + size) * 4, (1710 - size) * 4 + 1), ThreadLocalRandom.current().nextInt(0, (1710 - size) * 4 + 1), size, 3));
            ++this.object_id;
        }
        for (int i = 0; i < 16; ++i) {
            this.objects.add(new Lilypad(this.object_id, ThreadLocalRandom.current().nextInt(0, 1801), ThreadLocalRandom.current().nextInt(0, 6841), 130, 15, this));
            ++this.object_id;
            this.objects.add(new Lilypad(this.object_id, ThreadLocalRandom.current().nextInt(5040, 6841), ThreadLocalRandom.current().nextInt(0, 6841), 130, 15, this));
            ++this.object_id;
        }
        for (int i = 0; i < 1; ++i) {
            this.objects.add(new GameObject(this.object_id, ThreadLocalRandom.current().nextInt(2600, 6041) - 1800, ThreadLocalRandom.current().nextInt(800, 6041), 800, 11));
            ++this.object_id;
        }
        for (int i = 0; i < 0; ++i) {
            this.objects.add(new GameObject(this.object_id, ThreadLocalRandom.current().nextInt(3300, 5341) - 1800, ThreadLocalRandom.current().nextInt(1500, 5341), 1500, 14));
            final GameObject obj = (GameObject)this.objects.get(this.object_id);
            ++this.object_id;
            for (i = 0; i < 16; ++i) {
                this.objects.add(new GameObject(this.object_id, ThreadLocalRandom.current().nextInt(obj.getX() - 1500 + 130, obj.getX() + 1500 - 130 + 1), ThreadLocalRandom.current().nextInt(obj.getY() - 1500 + 130, obj.getY() + 1500 - 130 + 1), 130, 15));
                ++this.object_id;
            }
        }
        for (int i = 0; i < 6; ++i) {
            this.objects.add(new GameObject(this.object_id, ThreadLocalRandom.current().nextInt(0, 6841), ThreadLocalRandom.current().nextInt(0, 6841), 140, 12));
            ++this.object_id;
        }
        for (int i = 0; i < 6; ++i) {
            this.objects.add(new FoodSpot(this.object_id, ThreadLocalRandom.current().nextInt(0, 6841), ThreadLocalRandom.current().nextInt(0, 6841), 150, 5, this));
            ++this.object_id;
        }
        for (int i = 0; i < 4; ++i) {
            this.objects.add(new WaterSpot(this.object_id, ThreadLocalRandom.current().nextInt(1800, 6841) - 1800, ThreadLocalRandom.current().nextInt(0, 6841), 280, 4, this));
            ++this.object_id;
        }
        for (int i = 0; i < 3; ++i) {
            this.objects.add(new GameObject(this.object_id, ThreadLocalRandom.current().nextInt(0, 6841), ThreadLocalRandom.current().nextInt(0, 6841), 200, 10));
            ++this.object_id;
        }
        for (int i = 0; i < 1; ++i) {
            this.objects.add(new GameObject(this.object_id, ThreadLocalRandom.current().nextInt(1800, 6841) - 1800, ThreadLocalRandom.current().nextInt(0, 6841), 150, 13));
            ++this.object_id;
        }
        for (int i = 0; i < 2; ++i) {
            this.objects.add(new GameObject(this.object_id, ThreadLocalRandom.current().nextInt(1800, 6841) - 1800, ThreadLocalRandom.current().nextInt(0, 6841), 85, 9));
            ++this.object_id;
        }
        for (final GameObject object1 : this.objects) {
            for (final GameObject object2 : this.objects) {
                if (object1.getId() != object2.getId() && object1.getType() != 11 && object2.getType() != 11) {
                    this.collision(object1, object2);
                }
                if (object1.getType() == 11 && object2.getType() == 14) {
                    this.collision(object1, object2);
                }
            }
        }
        for (int i = 0; i < 35 / Math.round(2.0f); ++i) {
            this.objects.add(new ProtoEdible(this.object_id, ThreadLocalRandom.current().nextInt(1800, 6841) - 1800, ThreadLocalRandom.current().nextInt(0, 6841), random.nextBoolean() ? 60 : 42, 6, this, null));
            ++this.object_id;
        }
        for (int i = 0; i < 35; ++i) {
            this.objects.add(new Mushroom(this.object_id, ThreadLocalRandom.current().nextInt(1800, 6841) - 1800, ThreadLocalRandom.current().nextInt(0, 6841), 65, 8, this));
            ++this.object_id;
        }
        for (int i = 0; i < 35 / Math.round(2.0f); ++i) {
            this.objects.add(new ProtoEdible(this.object_id, ThreadLocalRandom.current().nextInt(1800, 6841) - 1800, ThreadLocalRandom.current().nextInt(0, 6841), random.nextBoolean() ? 60 : 42, 6, this, null));
            ++this.object_id;
        }
        for (int i = 0; i < 25; ++i) {
            this.objects.add(new RedMushroom(this.object_id, ThreadLocalRandom.current().nextInt(1800, 6841) - 1800, ThreadLocalRandom.current().nextInt(0, 6841), 65, 17, this));
            ++this.object_id;
        }
    }
    
    public void collision(final GameObject entity1, final GameObject entity2) {
        final double dx = entity2.getX() - entity1.getX();
        final double dy = entity2.getY() - entity1.getY();
        double dist = Math.sqrt(dx * dx + dy * dy);
        if (entity1.getRadius() + entity2.getRadius() >= dist) {
            if (dist <= 0.0) {
                dist = 1.0;
            }
            final double nx = dx / dist;
            final double ny = dy / dist;
            entity2.setX((int)(entity1.getX() + nx * (entity1.getRadius() + entity2.getRadius())));
            entity2.setY((int)(entity1.getY() + ny * (entity1.getRadius() + entity2.getRadius())));
        }
    }
    
    public void collisionDynamic(final GameObject entity1, final GameObject entity2) {
        final double dx = entity2.getX() - entity1.getX();
        final double dy = entity2.getY() - entity1.getY();
        double dist = Math.sqrt(dx * dx + dy * dy);
        if (entity1.getRadius() + entity2.getRadius() >= dist) {
            if (dist <= 0.0) {
                dist = 1.0;
            }
            final double nx = dx / dist;
            final double ny = dy / dist;
            final double distB1 = dist * (entity1.getRadius() / (entity1.getRadius() + entity2.getRadius()));
            final double cx = entity1.getX() + nx * distB1;
            final double cy = entity1.getY() + ny * distB1;
            entity1.setX((int)(cx - nx * entity1.getRadius()));
            entity1.setY((int)(cy - ny * entity1.getRadius()));
            entity2.setX((int)(cx - nx * entity2.getRadius()));
            entity2.setY((int)(cy - ny * entity2.getRadius()));
        }
    }
    
    public boolean collisionTest(final GameObject object1, final GameObject object) {
        final int dx = object1.getX() - object.getX();
        final int dy = object1.getY() - object.getY();
        final int dist = (int)Math.sqrt(dx * dx + dy * dy);
        return object.getRadius() + object1.getRadius() >= dist;
    }
    
    public void updateLeaderboard() {
        this.leaderboard.clear();
        for (final GameObject object : this.objects) {
            this.leaderboard.add(object);
        }
        final List<GameObject> toSend = new ArrayList<GameObject>();
        for (final GameObject object2 : this.leaderboard) {
            if (object2.getType() != 2 || (object2.getType() == 2 && ((Player)object2).isSpectator())) {
                this.leaderboard.remove(object2);
            }
        }
        Collections.sort(this.leaderboard);
        int a = 1;
        for (final GameObject object3 : this.leaderboard) {
            ((Player)object3).setRank(a);
            ++a;
            for (final GameObject object4 : this.leaderboard) {
                if (!object4.equals(object3) && object4.getId() == object3.getId()) {
                    this.leaderboard.remove(object4);
                }
            }
        }
        for (int i = 0; i < Math.min(10, this.leaderboard.size()); ++i) {
            toSend.add(this.leaderboard.get(i));
        }
        for (final GameObject player : this.leaderboard) {
            final MsgWriter toWrite = NetworkingTools.sendLeaderboard(toSend, (Player)player);
            NetworkingTools.sendMessage(((Player)player).getClient().getSocket(), toWrite);
        }
    }
    
    @Override
    public void run() {
        this.generate();
        while (true) {
            this.update();
            try {
                Thread.sleep(30L);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
    public void updatePlayerCount() {
        int players = 0;
        for (final Map.Entry pair : this.main.rooms.entrySet()) {
            //players += pair.getValue().leaderboard.size();
            //System.out.println("");
            continue;
        }
        this.playerCount = (short)players;
        for (final GameObject object : this.objects) {
            if (object.getType() == 2) {
                final Player player = (Player)object;
                NetworkingTools.sendMessage(player.getClient().getSocket(), NetworkingTools.updatePlayer(this));
            }
        }
    }
    
    public void initPlayer(final Player player) {
        player.reset();
        NetworkingTools.sendMessage(player.getClient().getSocket(), NetworkingTools.sendJoinPacket(this, player, 1));
        NetworkingTools.sendMessage(player.getClient().getSocket(), NetworkingTools.upgrade(player));
        for (final GameObject object : this.objects) {
            if (object.getType() == 2) {
                ((Player)object).toAdd.add(player);
            }
        }
        player.toAdd.clear();
        for (final GameObject o : this.objects) {
            player.toAdd.add(o);
        }
    }
    
    public void addSpectator(final Player player) {
        this.objects.add(player);
        player.setVelocityX(5);
        player.setVelocityY(5);
        player.reset();
        NetworkingTools.sendMessage(player.getClient().getSocket(), NetworkingTools.sendJoinPacket(this, player, 2));
        player.toAdd.clear();
        for (final GameObject o : this.objects) {
            player.toAdd.add(o);
        }
    }
    
    public void removePlayer(final Player player) {
        this.objects.remove(player);
        if (!player.isSpectator()) {
            for (final GameObject object : this.objects) {
                if (object.getType() == 2) {
                    ((Player)object).toRemove.add(player);
                    ((Player)object).removalMap.put(player, player);
                }
            }
        }
    }
    
    public void killPlayer(final Player player, final int reason, final Player kill) {
        NetworkingTools.sendMessage(player.getClient().getSocket(), NetworkingTools.sendDeath(player, reason));
        for (final GameObject object : this.objects) {
            if (object.getType() == 2) {
                ((Player)object).toRemove.add(player);
                ((Player)object).removalMap.put(player, kill);
            }
        }
        player.reset();
        player.setSpectator(true);
    }
    
    public void update() {
        for (final GameObject object : this.objects) {
            if (object.getType() == 13) {
                for (final GameObject player : this.objects) {
                    if (player.getType() == 2 && !((Player)player).isSpectator() && !((Player)player).isInHole() && this.collisionTest(player, object)) {
                        ((Player)player).setHole(object.getId());
                        ((Player)player).setInHole(true);
                        for (final GameObject toSend : this.objects) {
                            if (toSend.getType() == 2) {
                                ((Player)toSend).toRemove.add(player);
                                ((Player)toSend).removalMap.put(player, object);
                            }
                        }
                    }
                }
            }
            object.update();
        }
        this.updatePlayerCount();
        this.updateLeaderboard();
    }
}
