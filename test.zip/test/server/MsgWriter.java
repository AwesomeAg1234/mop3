// 
// Decompiled by Procyon v0.5.36
// 

package server;

import tools.Tools;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public class MsgWriter
{
    private int offset;
    private List<Byte> data;
    
    public MsgWriter() {
        this.data = new ArrayList<Byte>();
        this.setOffset(0);
    }
    
    public void writeUInt8(final int num) {
        this.data.add((byte)num);
        this.setOffset(this.getOffset() + 1);
    }
    
    public void writeUInt16(final short num) {
        final byte[] bytes = ByteBuffer.allocate(2).putShort(num).array();
        this.data.add(bytes[0]);
        this.setOffset(this.getOffset() + 1);
        this.data.add(bytes[1]);
        this.setOffset(this.getOffset() + 1);
    }
    
    public void writeUInt32(final int num) {
        final byte[] bytes = ByteBuffer.allocate(4).putInt(num).array();
        this.data.add(bytes[0]);
        this.setOffset(this.getOffset() + 1);
        this.data.add(bytes[1]);
        this.setOffset(this.getOffset() + 1);
        this.data.add(bytes[2]);
        this.setOffset(this.getOffset() + 1);
        this.data.add(bytes[3]);
        this.setOffset(this.getOffset() + 1);
    }
    
    private void writeByte(final byte byteData) {
        this.data.add(byteData);
        this.setOffset(this.getOffset() + 1);
    }
    
    public void writeString(String string) {
        string = Tools.encode_utf8(string);
        this.writeUInt16((short)(string.length() + 1));
        for (int i = 0; i < string.length(); ++i) {
            this.writeByte((byte)string.charAt(i));
        }
        this.writeByte((byte)109);
    }
    
    public byte[] getData() {
        final byte[] ret = new byte[this.data.size()];
        for (int i = 0; i < this.data.size(); ++i) {
            ret[i] = this.data.get(i);
        }
        return ret;
    }
    
    public int getOffset() {
        return this.offset;
    }
    
    public void setOffset(final int offset) {
        this.offset = offset;
    }
}
