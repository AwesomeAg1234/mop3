// 
// Decompiled by Procyon v0.5.36
// 

package server;

import tools.Tools;

public class MsgReader
{
    private int length;
    private int offset;
    private byte[] data;
    
    public MsgReader(final byte[] data) {
        this.setLength(this.length);
        this.offset = 0;
        this.data = data;
    }
    
    public short readInt16() {
        final short ret = (short)(((this.data[this.offset] & 0xFF) << 8) + (this.data[this.offset + 1] & 0xFF));
        this.offset += 2;
        return ret;
    }
    
    public short readUInt16() {
        if (this.data.length > this.offset + 1) {
            final int firstByte = 0xFF & this.data[this.offset];
            final int secondByte = 0xFF & this.data[this.offset + 1];
            this.offset += 2;
            char anUnsignedShort = (char)(firstByte << 8 | secondByte);
            if ((short)anUnsignedShort < 0) {
                anUnsignedShort = '\0';
            }
            return (short)anUnsignedShort;
        }
        return 0;
    }
    
    public int readUInt32() {
        if (this.data.length > this.offset + 3) {
            final int firstByte = 0xFF & this.data[this.offset];
            final int secondByte = 0xFF & this.data[this.offset + 1];
            final int thirdByte = 0xFF & this.data[this.offset + 2];
            final int fourthByte = 0xFF & this.data[this.offset + 3];
            this.offset += 4;
            long anUnsignedInt = (long)(firstByte << 24 | secondByte << 16 | thirdByte << 8 | fourthByte) & 0xFFFFFFFFL;
            if ((int)anUnsignedInt < 0) {
                anUnsignedInt = 0L;
            }
            return (int)anUnsignedInt;
        }
        return 0;
    }
    
    public int readUInt8() {
        int toReturn = 0;
        if (this.data.length > this.offset) {
            toReturn = (this.data[this.offset] & 0xFF);
            ++this.offset;
        }
        if (toReturn < 0) {
            toReturn = 0;
        }
        return toReturn;
    }
    
    public int getLength() {
        return this.length;
    }
    
    public void setLength(final int length) {
        this.length = length;
    }
    
    public byte[] getData() {
        return this.data;
    }
    
    public String readString() {
        String c = "";
        for (int a = this.readUInt16(), g = 0; g < a; ++g) {
            final int e = (byte)this.readUInt8();
            c = String.valueOf(c) + (char)e;
        }
        return Tools.decode_utf8(c);
    }
}
