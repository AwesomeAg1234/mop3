// 
// Decompiled by Procyon v0.5.36
// 

package server;

import java.nio.ByteBuffer;
import world.Room;
import java.util.concurrent.ThreadLocalRandom;
import org.java_websocket.handshake.ClientHandshake;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Collections;
import java.net.InetSocketAddress;
import org.java_websocket.drafts.Draft;
import objects.GameClient;
import org.java_websocket.WebSocket;
import java.util.concurrent.ConcurrentHashMap;
import main.Main;
import org.java_websocket.server.WebSocketServer;

public class Server extends WebSocketServer
{
    private Main main;
    public ConcurrentHashMap<WebSocket, GameClient> sockets;
    
    public Server(final int port, final Draft d, final Main main) throws UnknownHostException {
        super(new InetSocketAddress(port), (List)Collections.singletonList(d));
        this.sockets = new ConcurrentHashMap<WebSocket, GameClient>();
        this.main = main;
    }
    
    public Server(final InetSocketAddress address, final Draft d, final Main main) {
        super(address, (List)Collections.singletonList(d));
        this.sockets = new ConcurrentHashMap<WebSocket, GameClient>();
        this.main = main;
    }
    
    public void onOpen(final WebSocket conn, final ClientHandshake handshake) {
        if (this.sockets.get(conn) == null) {
            final int id = Math.max(ThreadLocalRandom.current().nextInt(1), 1);
            final GameClient newClient = new GameClient(conn, this.main.rooms.get(id));
            this.sockets.put(conn, newClient);
            newClient.onopen();
            this.main.handleNewClient(newClient, this.main.rooms.get(id));
        }
    }
    
    public void onClose(final WebSocket conn, final int code, final String reason, final boolean remote) {
        try {
            this.sockets.get(conn).onclose();
            this.sockets.remove(conn);
        }
        catch (Exception ex) {}
    }
    
    public void onError(final WebSocket conn, final Exception ex) {
        ex.printStackTrace();
    }
    
    public void onStart() {
        System.out.println("Server started! This line is test.");
    }
    
    public void onMessage(final WebSocket conn, final ByteBuffer blob) {
        try {
            this.sockets.get(conn).onmessage(new MsgReader(blob.array()));
        }
        catch (Exception ex) {}
    }
    
    public void onMessage(final WebSocket arg0, final String arg1) {
    }
}
