// 
// Decompiled by Procyon v0.5.36
// 

package tools;

import objects.Player;
import java.net.URLEncoder;
import javax.script.ScriptContext;
import javax.script.ScriptEngine;
import javax.script.Invocable;
import javax.script.ScriptException;
import javax.script.ScriptEngineManager;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

public class Tools
{
    public static String encode_utf8(final String string) {
        return unescape(encodeURIComponent(string));
    }
    
    public static String decode_utf8(final String string) {
        return decodeURIComponent(escape(string));
    }
    
    public static String decodeURIComponent(final String string) {
        try {
            return URLDecoder.decode(string, "UTF-8");
        }
        catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public static String unescape(final String string) {
        final ScriptEngineManager factory = new ScriptEngineManager();
        final ScriptEngine engine = factory.getEngineByName("JavaScript");
        final ScriptContext context = engine.getContext();
        try {
            engine.eval("function decodeStr(encoded){var result = unescape(encoded);return result;};", context);
        }
        catch (ScriptException e1) {
            e1.printStackTrace();
        }
        final Invocable inv = (Invocable)engine;
        try {
            final String res = (String)inv.invokeFunction("decodeStr", string);
            return res;
        }
        catch (NoSuchMethodException e2) {
            e2.printStackTrace();
        }
        catch (ScriptException e3) {
            e3.printStackTrace();
        }
        return null;
    }
    
    public static String escape(final String string) {
        final ScriptEngineManager factory = new ScriptEngineManager();
        final ScriptEngine engine = factory.getEngineByName("JavaScript");
        final ScriptContext context = engine.getContext();
        try {
            engine.eval("function encodeStr(decoded){var result = escape(decoded);return result;};", context);
        }
        catch (ScriptException e1) {
            e1.printStackTrace();
        }
        final Invocable inv = (Invocable)engine;
        try {
            final String res = (String)inv.invokeFunction("encodeStr", string);
            return res;
        }
        catch (NoSuchMethodException e2) {
            e2.printStackTrace();
        }
        catch (ScriptException e3) {
            e3.printStackTrace();
        }
        return null;
    }
    
    public static String encodeURIComponent(final String string) {
        try {
            final String encoded = URLEncoder.encode(string, "UTF-8").replaceAll("\\+", "%20").replaceAll("\\%21", "!").replaceAll("\\%27", "'").replaceAll("\\%28", "(").replaceAll("\\%29", ")").replaceAll("\\%7E", "~");
            return encoded;
        }
        catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public static int getAngle(final Player player, final int a) {
        int angle = (int)Math.toDegrees(Math.atan2(player.getMouseY() - player.getY(), player.getMouseX() - player.getX()));
        angle -= a;
        if (angle < 0) {
            angle += 360;
        }
        if (angle > 360) {
            angle = 0;
        }
        return angle;
    }
    
    public static int getNextLogicalAnimal(final Player player) {
        if (player.getScore() >= 10000000){
            return 37;
        }
        if (player.getScore() >= 2000000){
            return 31;
        }
        if (player.getScore() >= 1000000) {
            return 14;
        }
        if (player.getScore() >= 500000) {
            return 34;
        }
        if (player.getScore() >= 250000) {
            return 13;
        }
        if (player.getScore() >= 105000) {
            return 12;
        }
        if (player.getScore() >= 54000) {
            return 11;
        }
        if (player.getScore() >= 28500) {
            return 10;
        }
        if (player.getScore() >= 15000) {
            return 9;
        }
        if (player.getScore() >= 7900) {
            return 8;
        }
        if (player.getScore() >= 4200) {
            return 7;
        }
        if (player.getScore() >= 2100) {
            return 6;
        }
        if (player.getScore() >= 1000) {
            return 5;
        }
        if (player.getScore() >= 450) {
            return 4;
        }
        if (player.getScore() >= 200) {
            return 3;
        }
        if (player.getScore() >= 50) {
            return 2;
        }
        return 1;
    }
    
    public static int getNextAnimalGrowth(final Player player) {
        switch (player.getAnimal()) {
            case 1: {
                return 50;
            }
            case 2: {
                return 200;
            }
            case 3: {
                return 450;
            }
            case 4: {
                return 1000;
            }
            case 5: {
                return 2100;
            }
            case 6: {
                return 4200;
            }
            case 7: {
                return 7900;
            }
            case 8: {
                return 15000;
            }
            case 9: {
                return 28500;
            }
            case 10: {
                return 54000;
            }
            case 11: {
                return 105000;
            }
            case 12: {
                return 250000;
            }
            case 13: {
                return 500000;
            }
            case 34: {
                return 1000000;
            }
            case 14: {
                return 2000000;
            }
            case 31: {
                return 10000000;
            }
            case 37: {
                return 40000000;
            }
            default: {
                return 100000000;
            }
        }
    }
    
    public static boolean fastInMud(final Player player) {
        switch (player.getAnimal()) {
            case 1: {
                return false;
            }
            case 2: {
                return true;
            }
            case 3: {
                return true;
            }
            case 4: {
                return false;
            }
            case 8: {
                return false;
            }
            case 9: {
                return false;
            }
            case 11: {
                return true;
            }
            case 5: {
                return false;
            }
            case 6: {
                return false;
            }
            case 10: {
                return false;
            }
            case 12: {
                return true;
            }
            case 13: {
                return true;
            }
            case 7: {
                return false;
            }
            case 31: {
                return false;
            }
            case 34: {
                return true;
            }
            case 37: {
                return true;
            }
            default: {
                return true;
            }
        }
    }
    
    public static int getMinSize(final Player player) {
        switch (player.getAnimal()) {
            case 1: {
                return 42;
            }
            case 2: {
                return 42;
            }
            case 3: {
                return 80;
            }
            case 4: {
                return 90;
            }
            case 8: {
                return 120;
            }
            case 9: {
                return 120;
            }
            case 11: {
                return 120;
            }
            case 5: {
                return 80;
            }
            case 6: {
                return 80;
            }
            case 10: {
                return 130;
            }
            case 12: {
                return 135;
            }
            case 13: {
                return 120;
            }
            case 7: {
                return 100;
            }
            case 34: {
                return 120;
            }
            case 31: {
                return 50;
            }
            case 37: {
                return 10000;
            }
            default: {
                return 42;
            }
        }
    }
}
