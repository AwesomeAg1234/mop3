// 
// Decompiled by Procyon v0.5.36
// 

package tools;

import java.util.Iterator;
import java.util.List;
import java.util.HashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import objects.GameObject;
import java.util.ArrayList;
import objects.Player;
import world.Room;
import server.MsgWriter;
import org.java_websocket.WebSocket;

public class NetworkingTools
{
    public static void sendMessage(final WebSocket socket, final MsgWriter writer) {
        try {
            socket.send(writer.getData());
        }
        catch (Exception ex) {}
    }
    
    public static MsgWriter initClient(final Room room) {
        final MsgWriter writer = new MsgWriter();
        writer.writeUInt8(1);
        writer.writeUInt16(room.playerCount);
        writer.writeUInt16((short)153);
        return writer;
    }
    
    public static MsgWriter sendUpdatePacket(final Room room, final Player player, final int first) {
        final List<GameObject> objects = new ArrayList<GameObject>();
        final List<GameObject> objectsToUpdate = new ArrayList<GameObject>();
        for (final GameObject object : room.objects) {
            if (object.getType() == 2 && !((Player)object).isSpectator() && !((Player)object).isInHole()) {
                objectsToUpdate.add(object);
            }
            else {
                if (object.getType() == 2) {
                    continue;
                }
                objectsToUpdate.add(object);
            }
        }
        for (final GameObject object : player.toAdd) {
            if (object.getType() == 2 && !((Player)object).isSpectator()) {
                objects.add(object);
            }
            else {
                if (object.getType() == 2) {
                    continue;
                }
                objects.add(object);
            }
        }
        final MsgWriter writer = new MsgWriter();
        writer.writeUInt8(4);
        writer.writeUInt16((short)player.getX());
        writer.writeUInt16((short)player.getY());
        writer.writeUInt16((short)player.getZoom());
        writer.writeUInt8(player.isSpectator() ? 2 : 1);
        if (!player.isSpectator()) {
            writer.writeUInt8((player.getFlag() == 16) ? player.getAirLevel() : player.getWater());
            writer.writeUInt32(player.getScore());
            double percentage = (player.getScore() - player.getLastAni()) / (Tools.getNextAnimalGrowth(player) - player.getLastAni());
            percentage *= 100.0;
            writer.writeUInt8(Math.min((int)percentage, 100));
        }
        writer.writeUInt16((short)((first == 1) ? (objects.size() + 2) : objects.size()));
        for (final GameObject object2 : objects) {
            if (object2.getType() != 2) {
                writer.writeUInt8(object2.getType());
                writer.writeUInt32(object2.getId());
                writer.writeUInt16((short)object2.getRadius());
                writer.writeUInt16((short)object2.getX());
                writer.writeUInt16((short)object2.getY());
                writer.writeUInt8(0);
            }
            else {
                if (object2.getType() != 2) {
                    continue;
                }
                writer.writeUInt8(object2.getType());
                writer.writeUInt32(object2.getId());
                writer.writeUInt16((short)object2.getRadius());
                writer.writeUInt16((short)object2.getX());
                writer.writeUInt16((short)object2.getY());
                writer.writeUInt8(0);
                writer.writeUInt8(((Player)object2).getAnimal());
                writer.writeString(((Player)object2).getPlayerName());
            }
        }
        if (first == 1) {
            writer.writeUInt8(19);
            writer.writeUInt32(0);
            writer.writeUInt16((short)0);
            writer.writeUInt16((short)900);
            writer.writeUInt16((short)3420);
            writer.writeUInt8(0);
            writer.writeUInt16((short)450);
            writer.writeUInt16((short)1710);
            writer.writeUInt8(19);
            writer.writeUInt32(1);
            writer.writeUInt16((short)0);
            writer.writeUInt16((short)5940);
            writer.writeUInt16((short)3420);
            writer.writeUInt8(0);
            writer.writeUInt16((short)450);
            writer.writeUInt16((short)1710);
        }
        writer.writeUInt16((short)objectsToUpdate.size());
        for (final GameObject object2 : objectsToUpdate) {
            writer.writeUInt32(object2.getId());
            writer.writeUInt16((short)object2.getX());
            writer.writeUInt16((short)object2.getY());
            writer.writeUInt16((short)(object2.getRadius() / 4 * 10));
            if (object2.getType() == 2) {
                final Player playerObject = (Player)object2;
                writer.writeUInt8(playerObject.getAnimal());
                writer.writeUInt16((short)Tools.getAngle(playerObject, 0));
                writer.writeUInt8(player.getFlag());
                if ((player.getFlag() >> 0) % 2 != 0) {
                    writer.writeUInt8((player.getFlag() > 2000) ? 1 : 2);
                }
                if ((player.getFlag() >> 5) % 2 == 0) {
                    continue;
                }
                writer.writeUInt8(100);
            }
        }
        writer.writeUInt16((short)player.toRemove.size());
        for (final GameObject object2 : player.toRemove) {
            writer.writeUInt32(object2.getId());
            GameObject objectToMoveTo = object2;
            if (player.removalMap.get(object2) != null) {
                objectToMoveTo = player.removalMap.get(object2);
            }
            writer.writeUInt8(1);
            writer.writeUInt32(objectToMoveTo.getId());
        }
        player.toAdd = new CopyOnWriteArrayList<GameObject>();
        player.toRemove = new CopyOnWriteArrayList<GameObject>();
        player.removalMap = new HashMap<GameObject, GameObject>();
        return writer;
    }
    
    public static MsgWriter sendLeaderboard(final List<GameObject> toSend, final Player playerA) {
        final MsgWriter writer = new MsgWriter();
        writer.writeUInt8(8);
        writer.writeUInt8(playerA.getRank());
        if (toSend.contains(playerA)) {
            writer.writeUInt8(toSend.size());
        }
        else {
            writer.writeUInt8(toSend.size() + 1);
        }
        for (final GameObject player : toSend) {
            final Player player2 = (Player)player;
            writer.writeUInt8(player2.getRank());
            writer.writeString(player2.getPlayerName());
            writer.writeUInt32(player2.getScore());
        }
        if (!toSend.contains(playerA)) {
            writer.writeUInt8(playerA.getRank());
            writer.writeString(playerA.getPlayerName());
            writer.writeUInt32(playerA.getScore());
        }
        return writer;
    }
    
    public static MsgWriter sendJoinPacket(final Room room, final Player player, final int i) {
        final MsgWriter writer = new MsgWriter();
        writer.writeUInt8(2);
        if (room.playerCount >= 10) {
            writer.writeUInt8(0);
        }
        else {
            writer.writeUInt8(1);
            writer.writeUInt8(i);
            writer.writeUInt32(player.getId());
            writer.writeUInt16((short)room.getId());
            writer.writeUInt16((short)1710);
            writer.writeUInt16((short)1710);
            writer.writeUInt16((short)player.getX());
            writer.writeUInt16((short)player.getY());
            writer.writeUInt16((short)player.getZoom());
        }
        return writer;
    }
    
    public static MsgWriter sendDeath(final Player player, final int reason) {
        final MsgWriter writer = new MsgWriter();
        writer.writeUInt8(14);
        writer.writeUInt8(reason);
        player.setScore((int)Math.round(player.getScore() / 2.5));
        writer.writeUInt32(player.getScore());
        return writer;
    }
    
    public static MsgWriter upgrade(final Player player) {
        final MsgWriter writer = new MsgWriter();
        writer.writeUInt8(18);
        writer.writeUInt8(player.getAnimal());
        writer.writeUInt32(Tools.getNextAnimalGrowth(player));
        writer.writeUInt8(14 - player.getAnimal());
        for (int i = 0; i < 14 - player.getAnimal(); ++i) {
            writer.writeUInt8(14 - i);
        }
        writer.writeUInt8(player.getAnimal() - 1);
        for (int i = 1; i < player.getAnimal(); ++i) {
            writer.writeUInt8(i);
        }
        writer.writeUInt8(0);
        int edibleAmount = 0;
        if (player.getAnimal() >= 1 && player.getAnimal() != 5) {
            ++edibleAmount;
        }
        if (player.getAnimal() >= 3 && player.getAnimal() != 9) {
            ++edibleAmount;
        }
        if (player.getAnimal() >= 5 && player.getAnimal() != 9) {
            ++edibleAmount;
        }
        writer.writeUInt8(edibleAmount);
        if (player.getAnimal() != 5) {
            writer.writeUInt8(6);
        }
        if (player.getAnimal() >= 5 && player.getAnimal() != 9) {
            writer.writeUInt8(15);
        }
        if (player.getAnimal() >= 3 && player.getAnimal() != 9) {
            writer.writeUInt8(8);
        }
        return writer;
    }
    
    public static MsgWriter updatePlayer(final Room room) {
        final MsgWriter writer = new MsgWriter();
        writer.writeUInt8(10);
        writer.writeUInt16(room.playerCount);
        return writer;
    }
}
